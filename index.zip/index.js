require('dotenv').config();
const RPC = require('discord-rpc');
const fs = require('fs');
const path = require('path');

const { Client: SelfbotClient } = require('discord.js-selfbot-v13');
const axios = require('axios');
const { execSync } = require('child_process');


const config = {
    discordClientId: process.env.DISCORD_CLIENT_ID,
    jellyfinServerUrl: process.env.JELLYFIN_SERVER_URL || 'http://localhost:8096',
    jellyfinUserId: process.env.JELLYFIN_USER_ID,
    jellyfinApiKey: process.env.JELLYFIN_API_KEY,
    updateInterval: parseInt(process.env.UPDATE_INTERVAL) || 5000,
    useSelfbot: process.env.USE_SELFBOT === 'true',
    selfbotToken: process.env.SELFBOT_TOKEN
};


let rpc = null;
let selfbotClient = null;
let currentPresence = null;


if (!config.jellyfinUserId || !config.jellyfinApiKey) {
    console.error('ERROR: JELLYFIN_USER_ID and JELLYFIN_API_KEY are required in .env file');
    process.exit(1);
}


if (config.useSelfbot) {
    if (!config.selfbotToken) {
        console.error('ERROR: SELFBOT_TOKEN is required when USE_SELFBOT=true');
        console.error('💡 Set SELFBOT_TOKEN in your .env file with your Discord user token');
        process.exit(1);
    }
    console.log('🤖 Selfbot mode enabled - Discord Desktop does not need to be running');
} else {
    // Validate IPC mode requirements
    if (!config.discordClientId) {
        console.error('ERROR: DISCORD_CLIENT_ID is required in .env file (or enable USE_SELFBOT=true)');
        console.error('💡 Create a .env file based on env.example and add your Discord Client ID');
        console.error('💡 Get your Client ID from: https://discord.com/developers/applications');
        process.exit(1);
    }

    if (!/^\d+$/.test(config.discordClientId)) {
        console.error('ERROR: DISCORD_CLIENT_ID appears to be invalid (should be a numeric string)');
        console.error(`   Current value: ${config.discordClientId}`);
        console.error('💡 Get your Client ID from: https://discord.com/developers/applications');
        console.error('💡 Make sure you copy the "Application ID" (not the Client Secret)');
        process.exit(1);
    }
    
    
    rpc = new RPC.Client({ transport: 'ipc' });
}


function isDiscordRunning() {
    try {
        if (process.platform === 'win32') {
           
            const result = execSync('tasklist /FI "IMAGENAME eq Discord.exe" /FO CSV /NH', { 
                encoding: 'utf8',
                stdio: ['ignore', 'pipe', 'ignore']
            });
            return result.trim().length > 0 && result.includes('Discord.exe');
        } else {
            try {
                execSync('pgrep -f Discord', { stdio: 'ignore' });
                return true;
            } catch {
                return false;
            }
        }
    } catch (error) {
        // assume its running maybe
        return null;
    }
}


function checkDiscordIPC() {
    if (process.platform === 'win32') {
        const appData = process.env.APPDATA || process.env.LOCALAPPDATA;
        const discordPaths = [
            path.join(appData, 'discord', 'Local Storage', 'leveldb'),
            path.join(process.env.LOCALAPPDATA || '', 'Discord', 'Local Storage', 'leveldb')
        ];
        

        for (const discordPath of discordPaths) {
            if (fs.existsSync(path.dirname(discordPath))) {
                return true;
            }
        }
    }
    return null;
}


async function getJellyfinSessions() {
    const endpoints = ['/Sessions', '/emby/Sessions', 'Sessions'];
    
  
    const authHeaders = [
        {
            'X-Emby-Authorization': `MediaBrowser Client="Jellyfin Mobile RPC", Device="PC", DeviceId="rpc-client", Version="1.0.0", Token="${config.jellyfinApiKey}"`,
            'X-Emby-Token': config.jellyfinApiKey
        },
        {
            'Authorization': `MediaBrowser Token="${config.jellyfinApiKey}"`,
            'X-Emby-Token': config.jellyfinApiKey
        },
        {
            'X-Emby-Token': config.jellyfinApiKey
        }
    ];
    
    
    const baseUrl = config.jellyfinServerUrl.replace(/\/$/, '');
    
    for (const endpoint of endpoints) {
        for (const headers of authHeaders) {
            try {
                const url = `${baseUrl}/${endpoint}`;
                const response = await axios.get(url, { headers });
                return response.data;
            } catch (error) {
                
            }
        }
    }
    
    // If all attempts failed
    console.error('Error: Could not connect to Jellyfin API. Check your server URL and API key.');
    return [];
}

async function getJellyfinUserSessions() {
    try {
        
        const allSessions = await getJellyfinSessions();
        
        
        const userSessions = allSessions.filter(session => 
            session.UserId && session.UserId.toLowerCase() === config.jellyfinUserId.toLowerCase()
        );
        
        return userSessions;
    } catch (error) {
        console.error('Error fetching user sessions:', error.message);
        return [];
    }
}

async function getJellyfinUsers() {
    
    const endpoints = ['/Users', '/emby/Users', 'Users'];
    
    
    const authHeaders = [
        {
            'X-Emby-Authorization': `MediaBrowser Client="Jellyfin Mobile RPC", Device="PC", DeviceId="rpc-client", Version="1.0.0", Token="${config.jellyfinApiKey}"`,
            'X-Emby-Token': config.jellyfinApiKey
        },
        {
            'Authorization': `MediaBrowser Token="${config.jellyfinApiKey}"`,
            'X-Emby-Token': config.jellyfinApiKey
        },
        {
            'X-Emby-Token': config.jellyfinApiKey
        }
    ];
    
    
    const baseUrl = config.jellyfinServerUrl.replace(/\/$/, '');
    
    for (const endpoint of endpoints) {
        for (const headers of authHeaders) {
            try {
                const url = `${baseUrl}/${endpoint}`;
                const response = await axios.get(url, { headers });
                return response.data;
            } catch (error) {
                
            }
        }
    }
    
    return [];
}

async function getItemDetails(itemId) {

    const endpoints = [`/Items/${itemId}`, `/emby/Items/${itemId}`, `Items/${itemId}`];
    
    
    const authHeaders = [
        {
            'X-Emby-Authorization': `MediaBrowser Client="Jellyfin Mobile RPC", Device="PC", DeviceId="rpc-client", Version="1.0.0", Token="${config.jellyfinApiKey}"`,
            'X-Emby-Token': config.jellyfinApiKey
        },
        {
            'Authorization': `MediaBrowser Token="${config.jellyfinApiKey}"`,
            'X-Emby-Token': config.jellyfinApiKey
        },
        {
            'X-Emby-Token': config.jellyfinApiKey
        }
    ];
    
   
    const baseUrl = config.jellyfinServerUrl.replace(/\/$/, '');
    
    for (const endpoint of endpoints) {
        for (const headers of authHeaders) {
            try {
                const url = `${baseUrl}/${endpoint}`;
                const response = await axios.get(url, {
                    headers,
                    params: {
                        userId: config.jellyfinUserId
                    }
                });
                return response.data;
            } catch (error) {
                // Continue to next attempt
            }
        }
    }
    
    return null;
}

function getJellyfinImageUrl(itemId, imageType = 'Primary') {
    // normalize server url 
    const baseUrl = config.jellyfinServerUrl.replace(/\/$/, '');
    
    const imageUrl = `${baseUrl}/Items/${itemId}/Images/${imageType}`;
    return `${imageUrl}?api_key=${config.jellyfinApiKey}&maxWidth=1024`;
}

function isMobileDevice(session) {
    if (!session || !session.DeviceName) return false;
    const deviceName = session.DeviceName.toLowerCase();
    const clientName = (session.Client || '').toLowerCase();
    
    return deviceName.includes('mobile') || 
           deviceName.includes('android') || 
           deviceName.includes('ios') || 
           deviceName.includes('iphone') || 
           deviceName.includes('ipad') ||
           clientName.includes('mobile') ||
           clientName.includes('android') ||
           clientName.includes('ios');
}

function formatTime(seconds) {
    if (!seconds || seconds < 0) return '0:00';
    
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hours > 0) {
        return `${hours}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    } else {
        return `${minutes}:${String(secs).padStart(2, '0')}`;
    }
}

function formatRemainingTime(seconds) {
    if (!seconds || seconds < 0) return '0m left';
    
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (hours > 0 && minutes > 0) {
        return `${hours}h ${minutes}m left`;
    } else if (hours > 0) {
        return `${hours}h left`;
    } else {
        return `${minutes}m left`;
    }
}

function createProgressBar(current, total, barLength = 10) {
    if (!current || !total || total === 0) return '';
    
    const progress = Math.min(current / total, 1);
    const filled = Math.round(progress * barLength);
    const empty = barLength - filled;
    const filledChar = '▰';
    const emptyChar = '▱';
    return filledChar.repeat(filled) + emptyChar.repeat(empty);
}

function formatPercentage(current, total) {
    if (!current || !total || total === 0) return '0%';
    const percent = Math.round((current / total) * 100);
    return `${percent}%`;
}

function formatPlayerBar(currentSeconds, totalSeconds, isPaused, isMobile) {
    if (!currentSeconds || !totalSeconds) return '';
    
    const currentTime = formatTime(currentSeconds);
    const totalTime = formatTime(totalSeconds);
    const progress = createProgressBar(currentSeconds, totalSeconds, 12);
    const percentage = formatPercentage(currentSeconds, totalSeconds);
    
    const deviceIcon = isMobile ? '📱' : '🖥️';
    
    let playerBar = '';
    playerBar += `${currentTime} / ${totalTime}`;
    
    if (progress) {
        playerBar += ` ${progress}`;
    }
    
    playerBar += ` ${percentage}`;
    
    if (isMobile) {
        playerBar += ` │ ${deviceIcon} Mobile`;
    }
    
    if (playerBar.length > 128) {
        if (isMobile && playerBar.includes(` │ ${deviceIcon} Mobile`)) {
            const withoutMobile = playerBar.replace(` │ ${deviceIcon} Mobile`, '');
            if (withoutMobile.length <= 128) {
                playerBar = withoutMobile;
            }
        }
        
        if (playerBar.length > 128 && progress) {
            const shorterProgress = createProgressBar(currentSeconds, totalSeconds, 8);
            playerBar = playerBar.replace(progress, shorterProgress);
            
            if (playerBar.length > 128) {
                const evenShorterProgress = createProgressBar(currentSeconds, totalSeconds, 6);
                playerBar = playerBar.replace(shorterProgress, evenShorterProgress);
            }
        }
        
        if (playerBar.length > 128 && isMobile && playerBar.includes(` │ ${deviceIcon} Mobile`)) {
            playerBar = playerBar.replace(` │ ${deviceIcon} Mobile`, '');
        }
        
        if (playerBar.length > 128) {
            playerBar = playerBar.substring(0, 125) + '...';
        }
    }
    
    return playerBar;
}

function getPlaybackIconUrl(isPaused) {
    if (isPaused) {
        return 'https://cdn.sillydev.co.uk/u/TIm2kTVAzC8XWNM.png';
    } else {
        return 'https://cdn.sillydev.co.uk/u/2L9gCJFIAcl4c2L.png';
    }
}

function buildActivity(session) {
    const item = session.NowPlayingItem;
    const playState = session.PlayState;
    
    let title = item.Name || 'Unknown';
    let details = '';
    let state = '';
    let largeImageKey = 'jellyfin';
    let largeImageUrl = null;
    let smallImageKey = null;
    let smallImageText = '';

    if (item.Type === 'Movie') {
        details = title;
        if (item.ProductionYear) {
            state = `${item.ProductionYear}`;
        }
        largeImageKey = 'jellyfin_movie';
        if (item.Id) {
            largeImageUrl = getJellyfinImageUrl(item.Id, 'Primary');
        }
    } else if (item.Type === 'Episode') {
        const seriesName = item.SeriesName || 'Unknown Series';
        const episodeTitle = title;
        const seasonEpisode = item.IndexNumber ? `S${String(item.ParentIndexNumber || 0).padStart(2, '0')}E${String(item.IndexNumber).padStart(2, '0')}` : '';
        
        details = seriesName;
        if (episodeTitle && episodeTitle !== seriesName) {
            details += ` │ ${episodeTitle}`;
        }
        if (seasonEpisode) {
            details += ` │ ${seasonEpisode}`;
        }
        state = '';
        largeImageKey = 'jellyfin_episode';
        if (item.SeriesId) {
            largeImageUrl = getJellyfinImageUrl(item.SeriesId, 'Primary');
        } else if (item.Id) {
            largeImageUrl = getJellyfinImageUrl(item.Id, 'Primary');
        }
    } else if (item.Type === 'Audio') {
        const artistName = item.Artists && item.Artists.length > 0 ? item.Artists[0] : 'Unknown Artist';
        details = title;
        state = artistName;
        largeImageKey = 'jellyfin_music';
        if (item.Id) {
            largeImageUrl = getJellyfinImageUrl(item.Id, 'Primary');
        }
    } else {
        details = title;
        state = item.Type || 'Media';
        if (item.Id) {
            largeImageUrl = getJellyfinImageUrl(item.Id, 'Primary');
        }
    }

    const isPaused = playState.IsPaused === true;
    const isMobile = isMobileDevice(session);
    const playbackIconUrl = getPlaybackIconUrl(isPaused);
    smallImageKey = playbackIconUrl;
    smallImageText = isPaused ? 'Paused' : 'Playing';

    let startTimestamp = null;
    let endTimestamp = null;
    let currentTimeSeconds = null;
    let totalTimeSeconds = null;
    
    if (playState.PositionTicks && item.RunTimeTicks) {
        currentTimeSeconds = Math.floor(playState.PositionTicks / 10000000);
        totalTimeSeconds = Math.floor(item.RunTimeTicks / 10000000);
        
        if (!isPaused) {
            const remainingTimeSeconds = totalTimeSeconds - currentTimeSeconds;
            startTimestamp = Date.now() - (currentTimeSeconds * 1000);
            endTimestamp = Date.now() + (remainingTimeSeconds * 1000);
        }
    }
    
    let playerBarText = '';
    if (currentTimeSeconds && totalTimeSeconds) {
        playerBarText = formatPlayerBar(
            currentTimeSeconds,
            totalTimeSeconds,
            isPaused,
            isMobile
        );
    } else if (isMobile) {
        playerBarText = '📱 Mobile';
    }
    
    if (playerBarText) {
        if (item.Type === 'Episode') {
            state = playerBarText;
        } else {
            if (state) {
                state = `${state} │ ${playerBarText}`;
            } else {
                state = playerBarText;
            }
        }
    }

    const activity = {
        details: details,
        state: state,
        largeImageKey: largeImageKey, 
        largeImageText: details,
        startTimestamp: startTimestamp,
        endTimestamp: endTimestamp,
        instance: false,
        largeImageUrl: largeImageUrl 
    };

    if (smallImageKey) {
        activity.smallImageKey = smallImageKey;
        activity.smallImageText = smallImageText;
    }

    return { activity, session, isMobile, largeImageUrl };
}

async function updateDiscordPresence() {
    try {
        const sessions = await getJellyfinUserSessions();
        const activeSessions = sessions.filter(session => 
            session.NowPlayingItem && 
            session.PlayState
        );

        if (activeSessions.length === 0) {
            // no playback = wiping the discord rpc thingy
            if (config.useSelfbot && selfbotClient) {
                selfbotClient.user.setActivity(null);
            } else if (rpc) {
                await rpc.clearActivity();
            }
            currentPresence = null;
            return;
        }

        // Check for mobile sessions first
        const mobileSession = activeSessions.find(isMobileDevice);
        const session = mobileSession || activeSessions[0];

        if (!session.NowPlayingItem) {
            if (config.useSelfbot && selfbotClient) {
                selfbotClient.user.setActivity(null);
            } else if (rpc) {
                await rpc.clearActivity();
            }
            currentPresence = null;
            return;
        }

        const { activity, session: sessionData, isMobile, largeImageUrl } = buildActivity(session);

        
        if (config.useSelfbot && selfbotClient) {
    
            const selfbotActivity = {
                name: 'Jellyfin', 
                type: 0, // PLAYING
                details: activity.details,
                state: activity.state
            };
            
            
            if (activity.startTimestamp) {
                selfbotActivity.startTimestamp = Math.floor(activity.startTimestamp / 1000);
            }
            if (activity.endTimestamp) {
                selfbotActivity.endTimestamp = Math.floor(activity.endTimestamp / 1000);
            }
            
            // Note: Discord Rich Presence for selfbots requires registered asset keys in Discord Developer Portal.
            // Since arbitrary image URLs are not supported, we'll skip images to avoid question marks.
            // To enable images:
            // 1. Go to https://discord.com/developers/applications
            // 2. Select your application (or create one)
            // 3. Go to "Rich Presence" → "Art Assets"
            // 4. Upload images and note their asset keys (e.g., "jellyfin", "jellyfin_movie", etc.)
            // 5. Update the code to use those registered keys instead of URLs
            
            // For now, we'll skip images entirely to prevent question marks
            // Uncomment below and use registered asset keys if you've set them up:
            /*
            const assets = {};
            if (activity.largeImageKey && !activity.largeImageKey.startsWith('http')) {
                assets.large_image = activity.largeImageKey; // Must be a registered asset key
                if (activity.largeImageText) {
                    assets.large_text = activity.largeImageText;
                }
            }
            if (Object.keys(assets).length > 0) {
                selfbotActivity.assets = assets;
            }
            */
            
            selfbotClient.user.setActivity(selfbotActivity);
        } else if (rpc) {
           
            const ipcActivity = {
                ...activity,
                largeImageKey: activity.largeImageUrl || activity.largeImageKey
            };
            await rpc.setActivity(ipcActivity);
        }
        
        currentPresence = activity;
        
        const deviceInfo = isMobileDevice(sessionData) ? '📱 Mobile' : '💻 Desktop';
        
        if (largeImageUrl) {
            console.log(`Updated presence: ${activity.details} - ${activity.state} | ${deviceInfo} | Image: ${largeImageUrl.substring(0, 80)}...`);
        } else {
            console.log(`Updated presence: ${activity.details} - ${activity.state} | ${deviceInfo}`);
        }
        
    } catch (error) {
        console.error('Error updating Discord presence:', error.message);
    }
}

async function initializeDiscord() {
    // Verify user id
    const userIdFormat = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (!userIdFormat.test(config.jellyfinUserId)) {
        console.warn('⚠️  WARNING: User ID does not look like a valid Jellyfin UUID (should be format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx)');
        console.log('💡 To get your correct User ID, run: node get-user-id.js');
    }
    
    // Test API connection
    console.log('🔍 Testing Jellyfin API connection...');
    const testSessions = await getJellyfinSessions();
    console.log(`✅ Found ${testSessions.length} active session(s) on server`);
    
    if (testSessions.length > 0) {
        const userSessions = testSessions.filter(s => 
            s.UserId && s.UserId.toLowerCase() === config.jellyfinUserId.toLowerCase()
        );
        console.log(`📊 Found ${userSessions.length} session(s) for your user ID`);
        
        if (userSessions.length === 0 && testSessions.length > 0) {
            console.log('\n⚠️  No sessions found for your User ID. Available User IDs in current sessions:');
            const uniqueUserIds = [...new Set(testSessions.map(s => s.UserId).filter(Boolean))];
            uniqueUserIds.forEach(id => console.log(`   - ${id}`));
            console.log('\n💡 Update JELLYFIN_USER_ID in your .env file with one of the above IDs');
        }
    }
    console.log('---');
    
    await updateDiscordPresence();
    setInterval(updateDiscordPresence, config.updateInterval);
}

if (config.useSelfbot) {
    // Selfbot mode
    console.log('🤖 Initializing Discord selfbot...');
    if (config.selfbotToken) {
        console.log(`📋 Using selfbot token: ${config.selfbotToken.substring(0, 20)}...`);
    }
    
    selfbotClient = new SelfbotClient({
        checkUpdate: false 
    });
    
    selfbotClient.on('ready', async () => {
        try {
            console.log('✅ Connected to Discord via selfbot!');
            console.log(`👤 Logged in as: ${selfbotClient.user.tag}`);
            console.log(`📺 Monitoring Jellyfin for user: ${config.jellyfinUserId}`);
            console.log(`🔄 Update interval: ${config.updateInterval}ms`);
            console.log('---');
            
            await initializeDiscord();
        } catch (error) {
            console.error('Error in ready handler:', error.message);
            
            if (selfbotClient.user) {
                console.log('⚠️  Continuing despite error...');
                await initializeDiscord().catch(() => {});
            }
        }
    });
    
    selfbotClient.on('error', (error) => {
        console.error('Discord Selfbot Error:', error);
    });
    
    selfbotClient.login(config.selfbotToken).catch(err => {
        console.error('\n❌ Failed to connect to Discord selfbot:', err.message || err);
        console.error('\n🔍 Troubleshooting steps:');
        console.error('   1. Verify your SELFBOT_TOKEN is correct');
        console.error('   2. Make sure the token is valid and not expired');
        console.error('   3. Note: Selfbots violate Discord ToS - use at your own risk');
        process.exit(1);
    });
} else {
   
    console.log('🔌 Connecting to Discord via IPC...');
    console.log(`📋 Using Client ID: ${config.discordClientId}`);
    
    rpc.on('ready', async () => {
        console.log('✅ Connected to Discord!');
        console.log(`👤 Logged in as: ${rpc.user.username}#${rpc.user.discriminator}`);
        console.log(`📺 Monitoring Jellyfin for user: ${config.jellyfinUserId}`);
        console.log(`🔄 Update interval: ${config.updateInterval}ms`);
        console.log('---');
        
        await initializeDiscord();
    });

    rpc.on('error', (error) => {
        console.error('Discord RPC Error:', error);
    });

    const discordRunning = isDiscordRunning();
    if (discordRunning === false) {
        console.error('\n❌ ERROR: Discord does not appear to be running!');
        console.error('💡 Please start Discord Desktop app and try again.');
        console.error('💡 Make sure you are using Discord Desktop (not Discord web or mobile app)');
        console.error('💡 Alternatively, enable USE_SELFBOT=true in .env to use selfbot mode');
        process.exit(1);
    } else if (discordRunning === null) {
        console.log('⚠️  Could not verify if Discord is running, attempting connection anyway...');
    } else {
        console.log('✅ Discord process detected');
    }

    rpc.login({ clientId: config.discordClientId }).catch(err => {
        console.error('\n❌ Failed to connect to Discord:', err.message || err);
        console.error('\n🔍 Troubleshooting steps:');
        console.error('   1. Make sure Discord Desktop app is running (not web browser)');
        console.error('   2. Verify your DISCORD_CLIENT_ID is correct:');
        console.error(`      Current value: ${config.discordClientId}`);
        console.error('   3. Get your Client ID from: https://discord.com/developers/applications');
        console.error('      - Create a new application or select an existing one');
        console.error('      - Copy the "Application ID" (not Client Secret)');
        console.error('   4. Make sure Rich Presence is enabled in Discord:');
        console.error('      Settings → Activity Privacy → Display currently running game');
        console.error('   5. Try restarting Discord Desktop app');
        console.error('   6. Make sure you are logged into Discord Desktop');
        console.error('   7. Alternatively, enable USE_SELFBOT=true in .env to use selfbot mode');
        
        if (err.message && err.message.includes('TIMEOUT')) {
            console.error('\n⏱️  Connection timeout usually means:');
            console.error('   - Discord is not running');
            console.error('   - Discord is starting up (wait a few seconds and try again)');
            console.error('   - Discord IPC pipe is blocked');
        }
        
        process.exit(1);
    });
}


process.on('SIGINT', () => {
    console.log('\n👋 Shutting down...');
    if (rpc) {
        rpc.destroy();
    }
    if (selfbotClient) {
        selfbotClient.destroy();
    }
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('\n👋 Shutting down...');
    if (rpc) {
        rpc.destroy();
    }
    if (selfbotClient) {
        selfbotClient.destroy();
    }
    process.exit(0);
});

